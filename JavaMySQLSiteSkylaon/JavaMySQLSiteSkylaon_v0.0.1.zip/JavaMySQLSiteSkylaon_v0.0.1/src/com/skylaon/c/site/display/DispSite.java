package com.skylaon.c.site.display;

import com.skylaon.c.util.Cw;

public class DispSite {
	static private String SITE_NAME = "BOARD";
	static private String VERSION = "(v0.0.1)";
	static private String FEAT = "SkyLaon";

	static public void entranceTitle() {
		Cw.line();
		Cw.dot();
		Cw.space(22);
		Cw.w(SITE_NAME);
		Cw.w(VERSION);
		Cw.w(FEAT);
		Cw.space(22);
		Cw.dot();
		Cw.wn();
		Cw.line();
	}

}
