package com.skylaon.c.mysqlboard;

import java.util.Scanner;

import com.skylaon.c.mysqlboard.display.DispBoard;
import com.skylaon.c.util.Ci;
import com.skylaon.c.util.Cw;
import com.skylaon.c.util.Db;

public class ProcBoard {
	
	
	Scanner sc = new Scanner(System.in);
	
	public void run() {
		DispBoard.showTitle();
		Db.dbInit();
		
		loop:
			while(true) {
				Db.dbPostCount();
				DispBoard.showMenu();
				String cmd = Ci.r("명령입력");
				switch (cmd) {
				case "1":	// 글리스트
					ProcList.run();
					break;
				case "2":	// 게시물 검색
					ProcList.search();
					break;
				case "3":	// 글읽기
					ProcRead.run();
					break;
				case "4":	// 글쓰기
					ProcWrite.run();
					break;
				case "5":	// 글삭제
					ProcDel.run();
					break;
				case "6":	// 글수정	
					ProcUpdate.run();
					break;
				case "0":	// 관리자
					break;
				case "x":	// 사이트 메인으로 이동
					Cw.wn("사이트 메인으로 이동합니다.");
					break loop;
				}
			}
	}
	
	
}
