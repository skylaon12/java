package com.skylaon.c.mysqlboard;

import java.sql.SQLException;

import com.skylaon.c.util.Ci;
import com.skylaon.c.util.Cw;
import com.skylaon.c.util.Db;

public class ProcReply {
	public static void getComment(int no) {
		try {
			String sql = "select * from board where b_reply_ori = " + no; 
			Db.result = Db.st.executeQuery(sql);
			
			while(Db.result.next()) {				
				String comment = Db.result.getString("b_reply_text");
				String writer = Db.result.getString("b_id");
				Cw.wn("-> " + comment + "\t\t" + writer);
			}
		} catch (SQLException e) {
			Db.dbException(e);
		}
	}
	
	public static void setComment(int content_no) {
		String reply_writer = Ci.r("댓글 작성자 명");
		String comment = Ci.r("댓글입력");
		String sql = "insert into board (b_id, b_reply_ori, b_reply_text) values ('" + reply_writer + "'," + content_no + ",'" + comment + "');";
		Db.dbExecuteUpdate(sql);
		sql = "update board set b_reply_count = b_reply_count + 1 where b_no =" + content_no;
		Db.dbExecuteUpdate(sql);
		Cw.wn("댓글 작성이 완료되었습니다.");
	}
}
