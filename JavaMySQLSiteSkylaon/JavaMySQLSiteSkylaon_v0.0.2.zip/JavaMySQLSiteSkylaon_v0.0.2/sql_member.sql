create table member(
	s_id char(50) primary key,
    s_pw char(50) not null
);
