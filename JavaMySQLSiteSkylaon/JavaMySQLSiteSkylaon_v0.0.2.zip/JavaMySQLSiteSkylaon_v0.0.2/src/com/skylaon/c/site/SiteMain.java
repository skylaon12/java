package com.skylaon.c.site;

import com.skylaon.c.member.ProcMemberRegister;
import com.skylaon.c.mysqlboard.ProcBoard;
import com.skylaon.c.site.display.DispSite;
import com.skylaon.c.util.Ci;
import com.skylaon.c.util.Cw;
import com.skylaon.c.util.Db;

public class SiteMain {
	
	static private String cmd = "";
	
	static public void run() {
		Db.dbInit();
		loop:
			while(true) {
				DispSite.entranceTitle();
				cmd = Ci.r("[r]회원가입 [1]로그인 [a]관리자 [e]프로그램 종료 [b]게시판(임시입구)");
				switch (cmd) {
				case "r":
					ProcMemberRegister.run();
					break;
				case "1":
					break;
				case "2":
					break;
				case "a":
					break;
				case "e":
					Cw.wn("프로그램을 종료합니다.");
					break loop;
				case "b":
					ProcBoard procBoard = new ProcBoard();
					procBoard.run();
					break;

				default:
					Cw.wn("올바르지 않은 입력값입니다. 다시 입력해주십시오.");
				}
			}
	}

}
