package com.skylaon.c.mysqlboard;

import java.sql.SQLException;

import com.skylaon.c.mysqlboard.display.DispBoard;
import com.skylaon.c.util.Ci;
import com.skylaon.c.util.Cw;
import com.skylaon.c.util.Db;

public class ProcList {

	static public final int PER_PAGE = 3;

	static int startIndex = 0;
	static int currentPage = 1;
	static int totalPage = 0;
	static boolean isSearchMode = false;
	static String cmd;
	static String sql;
	static void run() {

		if (Db.getPostCount() % PER_PAGE == 0) {
			totalPage = Db.getPostCount() / PER_PAGE;
		} else {
			totalPage = Db.getPostCount() / PER_PAGE + 1;
		}
		Cw.wn("총 페이지 수 : " + totalPage);

		while (true) {
			cmd = Ci.r("페이지 번호 입력[이전 메뉴로 : x]");
			// x 입력 시
			if (cmd.equals("x")) {
				break;
			}
			// 이동 할 페이지
			try {
				currentPage = Integer.parseInt(cmd);
			} catch (NumberFormatException e) {
				Cw.wn("유효하지 않은 범위입니다.");
				continue;
			}
			// 올바르지 않은 값 입력 시
			if (currentPage > totalPage || currentPage < 0) {
				Cw.wn("유효하지 않은 범위입니다.");
				continue;
			}
			startIndex = (currentPage - 1) * PER_PAGE;
			sql = "select * from board where b_reply_ori is null limit " + startIndex + "," + PER_PAGE;
			getList(sql);

		}
	}

	static void search() {
		cmd = Ci.rl("검색어[x:나가기]");
		if (cmd.equals("x"))
			return;
		else
			searchList(cmd);
	}

	static void searchList(String searchWord) {
		int count = Db.getSearchedPostCount(searchWord);

		if (count % PER_PAGE == 0)
			totalPage = count / PER_PAGE;
		else
			totalPage = count / PER_PAGE + 1;
		Cw.wn("총 페이지 수 : " + totalPage);

		if (totalPage > 1) {
			while (true) {
				searchWord = Ci.r("페이지 번호 입력 <검색모드>[이전 메뉴로:x]");
				if (searchWord.equals("x")) {
					break;
				}

				try {
					currentPage = Integer.parseInt(searchWord);
				} catch (NumberFormatException e) {
					Cw.wn("유효하지 않은 범위입니다.");
					continue;
				}

				// 올바르지 않은 값 입력 시
				if (currentPage > totalPage || currentPage < 0) {
					Cw.wn("유효하지 않은 범위입니다.");
					continue;
				}

				startIndex = (currentPage - 1) * PER_PAGE;

				sql = "select * from board " +
				"where b_title like '%" + searchWord + "%'" +
						" limit " + startIndex + ", " + PER_PAGE + ";";
				getList(sql);
			}
		}
		else if(count == 0) {
			Cw.wn("검색 결과 존재하는 게시물이 없습니다.");
		}
		else  {
			sql = "select * from board \n" +
		"where b_title like '%" + searchWord + "%';";
			getList(sql);
		}

	}
	
	// 게시물 리스트 출력용
	private static void getList(String sql) {
		try {
			Db.result = Db.st.executeQuery(sql);
			DispBoard.titleList();
			while (Db.result.next()) {// 결과를 하나씩 빼기. 더이
				int index = Db.result.getInt("b_no");
				String title = Db.result.getString("b_title");
				String writer = Db.result.getString("b_id");
				int hit = Db.result.getInt("b_hit");
				int comment_num = Db.result.getInt("b_reply_count");
				String date = Db.result.getString("b_datetime");

				Cw.wn(index + "\t" + title + "\t" + writer + "\t" + hit + "\t" + comment_num + "\t" + date);

			}
		} catch (SQLException e) {
			Db.dbException(e);
		}
	}
}
