package com.skylaon.c.member;

import com.skylaon.c.util.Ci;
import com.skylaon.c.util.Cw;
import com.skylaon.c.util.Db;

public class ProcMemberLogin {
	
	public static String run() {
		// 로그인 작업 실행
		String id = "";
		String pw = "";
		while(true) {
			id = Ci.r("아이디");
			pw = Ci.r("비밀번호");
			
			if((id.length() == 0) || (pw.length() < 6) || (pw.length() > 14)) {
				Cw.wn("로그인 실패(유효하지 않은 범위입니다.)");
			}else break;
		}
		
		if(Db.isProcLogin(id,pw)) {
			Cw.wn("로그인 성공!");
			return id;
		}else {
			Cw.wn("로그인 실패!");
			return null;
		}
		
		
		
	}
}
