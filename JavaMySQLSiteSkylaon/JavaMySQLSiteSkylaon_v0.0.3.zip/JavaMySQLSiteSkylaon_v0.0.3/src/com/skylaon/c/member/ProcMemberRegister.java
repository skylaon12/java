package com.skylaon.c.member;

import com.skylaon.c.util.Ci;
import com.skylaon.c.util.Cw;
import com.skylaon.c.util.Db;

public class ProcMemberRegister {
	
	public static void run() {
		Cw.wn("======= 회원가입 =======");
		
		String id = "";
		String pw = "";
		boolean isVaild = true;
		
		while(true) {
			id = Ci.r("등록 할 아이디");
			pw = Ci.r("등록 할 패스워드(6~14자 입력)");
			
			isVaild = cheakInfo(id, pw);
			
			if(isVaild) {
				Db.dbExecuteUpdate("insert into member values('" + 
			id + "','" + pw + "');");
				Cw.wn("[회원가입이 완료되었습니다.]");
				break;
			}
			
		}
	}
	
	static private boolean cheakInfo(String id, String pw) {
		
		if((id.length() > 0)&& (pw.length()>6) && (pw.length() < 14)) {
			return true;
		}
		Cw.wn("입력 양식에 맞지 않습니다. 다시 입력해 주십시오.");
		return false;
	}
}
