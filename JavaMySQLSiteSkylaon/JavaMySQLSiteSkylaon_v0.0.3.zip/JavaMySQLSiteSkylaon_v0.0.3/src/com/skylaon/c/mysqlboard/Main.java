package com.skylaon.c.mysqlboard;

import com.skylaon.c.site.SiteMain;

public class Main {

	public static void main(String[] args) {

		SiteMain.run();
		
	}

}
