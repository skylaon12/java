package com.skylaon.c.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Db {
	static public Connection con = null;
	static public Statement st = null;
	static public ResultSet result = null;

	static public void dbInit() {
		try {
			String url = "jdbc:mysql://localhost:3306/my_board";
			String id = "root";
			String passwd = "root";
			Db.con = DriverManager.getConnection(url, id, passwd);
			st = con.createStatement();
		} catch (SQLException e) {
			Db.dbException(e);
		}
	}

	static public void dbExecuteUpdate(String query) {
		try {
			// (3/n) Statement 객체의 executeUpdate 함수에 sql문 실어서 db에서 실행되게 하기
			int resultCount = st.executeUpdate(query);
			System.out.println("처리된 행 수 : " + resultCount);
		} catch (SQLException e) {
			Db.dbException(e);
		}
	}

	static public void dbPostCount() {
		try {
			// (3/n) Statement 객체의 executeUpdate 함수에 sql문 실어서 db에서 실행되게 하기
			String sql = "select count(*) from board where b_reply_ori is null;";
			result = st.executeQuery(sql);
			result.next();
			String count = result.getString("count(*)");
			System.out.println("게시물 수 : " + count);
		} catch (SQLException e) {
			Db.dbException(e);
		}
	}

	static public int getPostCount() {
		int pageCount = 0;
		try {
			String sql = "select count(*) from board where b_reply_ori is null;";
			result = st.executeQuery(sql);
			result.next();
			pageCount = result.getInt("count(*)");
		} catch (SQLException e) {
			dbException(e);
		}
		return pageCount;
	}

	static public int getSearchedPostCount(String searchWord) {
		int pageCount = 0;
		try {
			String sql = "select count(*) from board " + "where b_title like '%" + searchWord + "%';";
			result = st.executeQuery(sql);
			result.next();
			pageCount = result.getInt("count(*)");
		} catch (SQLException e) {
			dbException(e);
		}
		return pageCount;
	}
	
	static public boolean isProcLogin(String id, String pw) {
		int count = 0;
		String sql = "select count(*) from member where s_id = '" + id + "' and s_pw = '" + pw + "';";
		try {
			result = st.executeQuery(sql);
			result.next();
			count = result.getInt("count(*)");
		} catch (SQLException e) {
			dbException(e);
		}
		
		if(count == 1) {
			return true;
		}else
			return false;
	

	}
	
	static public void dbException(SQLException e) {
		System.out.println("SQLException : " + e.getMessage());
		System.out.println("SQLState : " + e.getSQLState());
	}

}
