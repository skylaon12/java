package com.skylaon.c.board;

import com.skylaon.util.Cw;

public class ProcMenuRead {
	
	static void run() {
		// todo
		// 임시
		Cw.wn("읽기");
	}
}
