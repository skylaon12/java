package com.skylaon.c.board;

import com.skylaon.c.board.display.Disp;

public class Board {
	
	public static final String VERSION = "v0.0.0";
	public static final String TITLE = "고양이 게시판 (" + VERSION + ") feat. skylaon";
	public void run() {
		Disp.title();
		ProcMenu.run();
	}
}
