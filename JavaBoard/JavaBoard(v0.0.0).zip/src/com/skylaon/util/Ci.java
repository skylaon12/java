package com.skylaon.util;

import java.util.Scanner;


public class Ci {
	static Scanner sc = new Scanner(System.in);
	static public String r() {
		return sc.next();
	}
	static public String r(String comment) {
		Cw.w(comment+":");
		return sc.next();
	}
}
