package com.skylaon.c.board;

import com.skylaon.c.board.data.Data;
import com.skylaon.c.board.data.Post;
import com.skylaon.util.Cw;

public class ProcMenuList {

	static void run() {
		// todo
		// 임시
		if (Data.posts.size() == 0) {
			Cw.wn("등록된 게시물이 없습니다.");
		} else {
			Cw.wn("게시물 번호\t제목\t작성자\t조회수\t작성일");
			for (Post p : Data.posts) {
				p.infoForList();
			}
		}

	}
}
