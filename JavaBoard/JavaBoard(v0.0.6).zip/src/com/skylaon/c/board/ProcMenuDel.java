package com.skylaon.c.board;

import com.skylaon.c.board.data.Data;
import com.skylaon.c.board.data.Post;
import com.skylaon.util.Ci;
import com.skylaon.util.Cw;

public class ProcMenuDel {
	
	static void run() {
		// todo
		// 임시
		Cw.wn("글삭제");
		int cmd = Ci.r_int("삭제할 글 번호");// 정수형으로 받음
		////	1.삭제할 글 찾기(바로 삭제하지 말고)	////
		// *주의* 바로 삭제 시 문제가 생길 수 있음	//
		//// 옛날 for문 방식	////
		//int tempSearchIndex = 0;
		Post.no--;	// static 상의 no 변수 1 감소 -> 하나 삭제하면 instanceNo도 하나씩 줄여야 하기 때문
		if(cmd != Data.posts.size()) {
			for(int i = Data.posts.get(cmd).instanceNo - 1; i < Data.posts.size(); i++) {
				Data.posts.get(i).instanceNo--;
			}
		}
		// 내가 입력한 번호 다음 게시물의 instanceNo를 1씩 감소
		
		// 내가 삭제하려는 게시물의 번호랑 그 다음 게시물의 번호는 같기 때문에 삭제했다면
		// break문 통해서 나오도록함.
		// 삭제를 하더라도 순서는 바뀌지 않기 때문
//		for(int i = 0; i < Data.posts.size(); i++) {
//			if(cmd == Data.posts.get(i).instanceNo) {
//				tempSearchIndex = i;
//				break;
//			}
//		}
		// 인덱싱으로 접근
		// -> 어차피 위의 로직에서 정렬되기 때문
		Data.posts.remove(cmd-1);
		Cw.wn("글 수:"+Data.posts.size());
		
			
		
		
	}
}
