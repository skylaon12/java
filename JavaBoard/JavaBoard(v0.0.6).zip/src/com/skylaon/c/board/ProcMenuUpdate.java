package com.skylaon.c.board;

import com.skylaon.c.board.data.Data;
import com.skylaon.c.board.data.Post;
import com.skylaon.util.Ci;
import com.skylaon.util.Cw;

public class ProcMenuUpdate {
	static void run() {
		Cw.wn("업데이트 실행");
		String cmd = Ci.r("수정할 글 번호");
		// 수정 할 글 찾기
		for(Post p: Data.posts) {
			if(cmd.equals(p.instanceNo+"")) {// 찾으면~
				String content = Ci.rl("수정 할 글내용");
				p.content = content;	// 글 내용 덮어쓰기
				Cw.wn("게시물 수정이 완료되었습니다.");
			}
		}
	}
}
