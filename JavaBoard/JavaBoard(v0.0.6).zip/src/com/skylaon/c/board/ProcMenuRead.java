package com.skylaon.c.board;

import com.skylaon.c.board.data.Data;
import com.skylaon.c.board.data.Post;
import com.skylaon.util.Ci;
import com.skylaon.util.Cw;

public class ProcMenuRead {
	
	static void run() {
		// todo
		// 임시
		Cw.wn("읽기");
		String cmd = Ci.r("읽을 글 번호");
		for(Post p:Data.posts) {
			if(cmd.equals(p.instanceNo+"")) {
				p.hit++;
				p.infoForRead();
			}
		}
	}
}
