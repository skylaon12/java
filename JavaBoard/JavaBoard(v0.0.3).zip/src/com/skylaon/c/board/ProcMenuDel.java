package com.skylaon.c.board;

import com.skylaon.util.Cw;

public class ProcMenuDel {
	
	static void run() {
		// todo
		// 임시
		Cw.wn("글삭제");
	}
}
