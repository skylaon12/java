package com.skylaon.c.board;

import com.skylaon.c.board.data.Data;
import com.skylaon.c.board.data.Post;
import com.skylaon.util.Ci;
import com.skylaon.util.Cw;

public class ProcMenuWrite {
	
	static void run() {
		// todo
		// 임시
		Cw.wn("쓰기");
		String title;
		while(true) {
			title=Ci.rl("글제목");
			if(title.length() > 0) {
				break;
			}else {
				Cw.wn("장난 x");
			}
		}
		String content;
		while(true) {
			content=Ci.rl("내용");
			if(content.length() > 0) {
				break;
			}else {
				Cw.wn("장난 x");
			}
		}
		String writer;
		while(true) {
			writer=Ci.rl("작성자");
			if(writer.length() > 0) {
				break;
			}else {
				Cw.wn("장난 x");
			}
		}
		Post k = new Post("고양이", "귀엽다", "개", 0);
		Post p = new Post(title, content, writer, 0);
		
		Data.posts.add(k);
		Data.posts.add(p);
		Cw.wn("글 작성됨");
	}
}
