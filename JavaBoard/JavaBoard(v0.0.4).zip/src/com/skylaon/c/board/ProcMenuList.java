package com.skylaon.c.board;

import com.skylaon.c.board.data.Data;
import com.skylaon.c.board.data.Post;
import com.skylaon.util.Cw;

public class ProcMenuList {

	static void run() {
		// todo
		// 임시
		if (Data.posts.size() == 0) {
			Cw.wn("등록된 게시물이 없습니다.");
		} else {
			for (Post p : Data.posts) {
				p.infoForList();
			}
		}

	}
}
