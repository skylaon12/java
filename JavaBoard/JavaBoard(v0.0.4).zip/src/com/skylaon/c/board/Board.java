package com.skylaon.c.board;

import com.skylaon.c.board.data.Data;
import com.skylaon.c.board.display.Disp;

public class Board {
	
	public static final String VERSION = "v0.0.4";
	public static final String TITLE = "고양이 게시판 (" + VERSION + ") feat. skylaon";
	public void run() {
		Data.loadData();
		Disp.title();
		ProcMenu.run();
	}
}
