package com.skylaon.c.board;

import com.skylaon.c.board.data.Data;
import com.skylaon.util.Ci;
import com.skylaon.util.Cw;

public class ProcMenuDel {
	
	static void run() {
		// todo
		// 임시
		Cw.wn("글삭제");
		String cmd = Ci.r("삭제할 글 번호");
		////	1.삭제할 글 찾기(바로 삭제하지 말고)	////
		// *주의* 바로 삭제 시 문제가 생길 수 있음	//
		//// 옛날 for문 방식	////
		int tempSearchIndex = 0;
		for(int i = 0; i < Data.posts.size(); i++) {
			if(cmd.equals(Data.posts.get(i).instanceNo+"")) {
				tempSearchIndex = i;
			}
		}
		Data.posts.remove(tempSearchIndex);
		Cw.wn("글 수:"+Data.posts.size());
		
			
		
		
	}
}
