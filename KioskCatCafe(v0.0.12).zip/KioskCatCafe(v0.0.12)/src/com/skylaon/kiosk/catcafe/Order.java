package com.skylaon.kiosk.catcafe;

import com.skylaon.kiosk.catcafe.product.Product;

public class Order {
	
	public Product selectedProduct;
	public int optionHotCold = 0;	// 1: hot, 2:cold
	public int orderCnt = 1;		// 주문 된 횟수 -> 중복 주문 유무
									// hot ice중복에 대해선 다음에 생각
	public Order(Product selectedProduct) {
		this.selectedProduct = selectedProduct;
		this.orderCnt++;
		
	}

	public Order(Product selectedProduct, int optionHotCold) {
		this.selectedProduct = selectedProduct;
		this.optionHotCold = optionHotCold;
		this.orderCnt++;
	}
}
