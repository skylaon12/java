package com.skylaon.kiosk.catcafe;

import com.skylaon.util.Cw;

//자동임포트 단축키: ctrl+shift+o(영문자O)
public class Kiosk {
	
	public static final String VERSION = "0.0.12";	//버전 표시용.

	void run() {
		KioskObj.productLoad();	//상품로드
		Disp.d_title();
		xx:while(true) {
			Disp.d_main();
			
			switch(KioskObj.input()) {
			case 1:
				ProcMenuDrink.run();
				break;
			case 2:
				ProcMenuDessert.run();
				break;
			case 0:
				Disp.d_PayCheck();
				break xx;
			default:
				Cw.wn("유효하지 않은 입력값입니다. 다시 입력하십시오.");
			}
		}		
	}
}