package com.skylaon.kiosk.catcafe;

import com.skylaon.util.Cw;

public class ProcMenuDrink {
	
	public static void run() {
		yy:while(true) {
			Disp.drink_menu(KioskObj.drink_products);
			int num = KioskObj.input();
			if(num == 0) {
				Cw.wn("이전 메뉴 이동");
				break yy;
			}else if((num < 0) || (num > KioskObj.drink_products.size())) {
				Cw.wn("유효하지 않은 입력값 입니다. 다시 입력하십시오.");
				continue;
			}else {
				ProcMenuOptionHotCold.run(KioskObj.drink_products.get(num-1));
			}
		}
	}
}