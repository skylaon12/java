package com.skylaon.kiosk.catcafe;

import com.skylaon.util.Cw;

public class ProcMenuDessert {
	
	public static void run() {
		
		while(true) {
			Disp.dessert_menu(KioskObj.dessert_products);
			Boolean exist = true;	// 기존에 주문했는지 여부
			
			int num = KioskObj.input();
			
			if(num == 0) {
				Cw.wn("이전 메뉴 이동");
				break;
			// 유효하지 않은 입력 시 (음수 or num > 디저트 종류 개수 
			}else if((num < 0) || (num > KioskObj.dessert_products.size())) {
				Cw.wn("유효하지 않은 입력값 입니다. 다시 입력하십시오.");
				continue;
			}else {
				Order n = new Order(KioskObj.dessert_products.get(num-1));
				
				for(Order o : KioskObj.basket) {
					// 중복주문인 경우
					if(n.selectedProduct.name == o.selectedProduct.name) {
						Cw.wn(n.selectedProduct.name+" 선택됨");
						o.orderCnt++; // 주문이력에 해당상품 수량 추가
						exist = false;
					}
				}
				// 중복인 경우 false로 바뀌어서 통과하고 신규주문인 경우 아래 if문 진입 
				if(exist) {
					Cw.wn(n.selectedProduct.name+" 선택됨");
					KioskObj.basket.add(n);	//오더 추가
				}
				
				break;
			}
			
		}
	}
}
