package com.skylaon.kiosk.catcafe;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.skylaon.kiosk.catcafe.product.Dessert;
import com.skylaon.kiosk.catcafe.product.Drink;
import com.skylaon.kiosk.catcafe.product.Product;
import com.skylaon.util.Cw;

public class KioskObj {
	public static ArrayList<Order> basket = new ArrayList<>();	//주문들
	public static ArrayList<Product> products = new ArrayList<>();	//상품들
	public static ArrayList<Drink> drink_products = new ArrayList<>(); // 음료 상품들
	public static ArrayList<Dessert> dessert_products = new ArrayList<>(); // 음료 상품들
	
	public static Scanner sc = new Scanner(System.in);
	public static int cmd;
	public static String cmd_s;
	public static void productLoad() {
		drink_products.add(new Drink("커피",1000,true));	////	상품목록 처리	////
		drink_products.add(new Drink("오렌지쥬스",2000));
		dessert_products.add(new Dessert("마카롱",3000));
//		products.add(new Product("키티피규어",10000));
	}
	
	// 입력 전용
	public static int input() {
		try {
			cmd = sc.nextInt();
			return cmd;
		} catch (InputMismatchException e) {
			// TODO: handle exception
			sc = new Scanner(System.in);
			Cw.wn("유효하지 않은 입력값입니다. 다시 입력하십시오.");
			input();
			return cmd;
		}
	}
	// 문자입력
	public static String input_str() {
			cmd_s = sc.next();
			return cmd_s;		
	}
}
