package com.skylaon.kiosk.catcafe;

import com.skylaon.kiosk.catcafe.product.Drink;
import com.skylaon.kiosk.catcafe.product.Product;
import com.skylaon.util.Cw;

public class ProcMenuOptionHotCold {

	public static void run(Product p) {
		// p.option -> true면? 해당 음료는 ice hot을 선택할 수 있다는 뜻(뜨아,아아)
		// -> false면? 선택할 수 없는 음료(오렌지 쥬스)
		Boolean exist = true;
		if (((Drink) p).option) {

			loop: while (true) {
				Cw.wn("[1.hot/2.cold(+500원)/0.이전메뉴로]");
				int num = KioskObj.input();

				switch (num) {
				case 1:
					Cw.wn("hot 선택됨. 이전 메뉴 이동");
					for (Order o : KioskObj.basket) {
						if (p.name == o.selectedProduct.name) {
							o.orderCnt++;
							exist = false;
							break loop;
						}
					}
					if (exist)
						KioskObj.basket.add(new Order(p, 1)); // 오더 추가
					break loop;
				case 2:
					Cw.wn("ice 선택됨. 이전 메뉴 이동");
					for (Order o : KioskObj.basket) {
						if (p.name == o.selectedProduct.name) {
							o.orderCnt++;
							exist = false;
							break loop;
						}
					}
					if (exist)
						KioskObj.basket.add(new Order(p, 2)); // 오더 추가
					break loop;
				case 0:
					Cw.wn("이전 메뉴 이동");
					break loop;
				default:
					Cw.wn("유효하지 않은 입력값입니다. 다시 입력하십시오.");
				}
			}
		} else {
			Cw.wn(p.name + " 선택됨");
			for (Order o : KioskObj.basket) {
				if (p.name == o.selectedProduct.name) {
					o.orderCnt++;
					exist = false;
				}
			}
			// 위에서 만족하면 exist는 false니까 아래 if문을 안들어감
			if (exist)
				KioskObj.basket.add(new Order(p)); // 오더 추가
		}

	}
}
