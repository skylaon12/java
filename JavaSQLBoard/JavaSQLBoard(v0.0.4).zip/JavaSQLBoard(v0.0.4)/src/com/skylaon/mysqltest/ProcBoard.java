package com.skylaon.mysqltest;

import java.sql.SQLException;
import java.util.Scanner;

import com.skylaon.c.board.display.Display;
import com.skylaon.util.Ci;
import com.skylaon.util.Cw;
import com.skylaon.util.Db;

public class ProcBoard {
	
	
	Scanner sc = new Scanner(System.in);
	
	void run() {
		Display.showTitle();
		Db.dbInit();
		
		loop:
			while(true) {
				Db.dbPostCount();
				Display.showMenu();
				String cmd = Ci.r("명령입력");
				switch (cmd) {
				case "1":	// 글리스트
					ProcList.run();
					break;
				case "2":	// 글읽기
					System.out.println("읽을 글 번호를 입력해주세요 : ");
					String readNo = sc.next();
					try {
						Db.result = Db.st.executeQuery("select * from board where b_no = " + readNo);
						Db.result.next();	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨
						String title = Db.result.getString("b_title");
						String content = Db.result.getString("b_text");
						Cw.wn("글 제목 : " + title);
						Cw.wn("글 내용 : " + content);
					} catch (SQLException e) {
						Db.dbException(e);
					}
					break;
				case "3":	// 글쓰기
					Cw.w("작성자 id : ");
					String writer = sc.next();
					Cw.w("글 제목 : ");
					String title = sc.next();
					Cw.w("내용 입력 : ");
					String contents = sc.next();
					int in_no = 0;	// b_no 조정
					try {// board 테이블의 마지막 행의 번호를 가져와 임시변수 in_no에 저장
						Db.result = Db.st.executeQuery("select b_no from board order by b_no desc limit 1");
						Db.result.next();
						in_no = Db.result.getInt("b_no");						
					} catch (SQLException e) {
						Db.dbException(e);
					}
					// 글 등록하기 전에 b_no를 마지막 행의 번호 다음으로 지정
					Db.dbExecuteUpdate("alter table board auto_increment = " + in_no + ";");
					Db.dbExecuteUpdate("insert into board(b_title, b_id, b_datetime, b_text) values('"+title+"','" + writer + "',now(),'" + contents + "');");		
					Cw.wn("등록이 완료되었습니다.");
					break;
				case "4":	// 글삭제
					String no = Ci.r("삭제할 글 번호 : ");
					Db.dbExecuteUpdate("delete from board where b_no = " + no + ";");
					// `삭제 이후에 b_no를 재정렬
					Db.dbExecuteUpdate("alter table board auto_increment=1;");
					Db.dbExecuteUpdate("set @count = 0;");
					Db.dbExecuteUpdate("update board set b_no = @count :=@count+1");
					break;
				case "5":	// 글수정
					String editNo = Ci.r("수정할 글 번호를 입력해주세요 : ");
					String editTitle = Ci.rl("제목 : ");
					String editContent = Ci.rl("내용 : ");
					
					Db.dbExecuteUpdate("update board set b_title = '" + editTitle + "',b_text = '" + editContent + "' where b_no = " + editNo + ";");
					
				case "0":	// 관리자
					break;
				case "e":	// 프로그램 종료
					Cw.wn("프로그램을 종료합니다.");
					break loop;
				}
			}
	}
	
	
}
