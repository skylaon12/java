package com.skylaon.mysqltest;

import java.sql.SQLException;

import com.skylaon.util.Ci;
import com.skylaon.util.Cw;
import com.skylaon.util.Db;

public class ProcList {

	static public final int PER_PAGE = 4;

	static void run() {

		int startIndex = 0;
		int currentPage = 1;

		int totalPage = 0;
		if (Db.getPostCount() % PER_PAGE == 0) {
			totalPage = Db.getPostCount() / PER_PAGE;
		} else {
			totalPage = Db.getPostCount() / PER_PAGE + 1;
		}
		Cw.wn("총 페이지 수 : " + totalPage);

		String cmd;

		while (true) {
			cmd = Ci.r("페이지 번호 입력[이전 메뉴로 : x]");
			// x 입력 시
			if (cmd.equals("x")) {
				break;
			}
			// 이동 할 페이지
			currentPage = Integer.parseInt(cmd);
			// 올바르지 않은 값 입력 시
			if (currentPage > totalPage || currentPage < 0) {
				Cw.wn("유효하지 않은 범위입니다.");
				continue;
			}

			try {
				startIndex = (currentPage - 1) * PER_PAGE;
				Db.result = Db.st.executeQuery("select * from board limit " + startIndex + "," + PER_PAGE);
				System.out.println("번호\t제목\t글쓴이\t조회수\t작성일");
				while (Db.result.next()) {// 결과를 하나씩 빼기. 더이
					int index = Db.result.getInt("b_no");
					String title = Db.result.getString("b_title");
					String writer = Db.result.getString("b_id");
					int hit = Db.result.getInt("b_hit");
					String date = Db.result.getString("b_datetime");

					Cw.wn(index + "\t" + title + "\t" + writer + "\t" + hit + "\t" + date);
				}
			} catch (SQLException e) {
				// TODO: handle exception
			}

		}
	}
}
