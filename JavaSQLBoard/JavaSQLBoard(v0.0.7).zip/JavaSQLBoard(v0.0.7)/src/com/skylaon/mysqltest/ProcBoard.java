package com.skylaon.mysqltest;

import java.util.Scanner;

import com.skylaon.c.board.display.Display;
import com.skylaon.util.Ci;
import com.skylaon.util.Cw;
import com.skylaon.util.Db;

public class ProcBoard {
	
	
	Scanner sc = new Scanner(System.in);
	
	void run() {
		Display.showTitle();
		Db.dbInit();
		
		loop:
			while(true) {
				Db.dbPostCount();
				Display.showMenu();
				String cmd = Ci.r("명령입력");
				switch (cmd) {
				case "1":	// 글리스트
					ProcList.run();
					break;
				case "2":	// 게시물 검색
					ProcList.search();
					break;
				case "3":	// 글읽기
					ProcRead.run();
					break;
				case "4":	// 글쓰기
					ProcWrite.run();
					break;
				case "5":	// 글삭제
					ProcDel.run();
					break;
				case "6":	// 글수정	
					ProcUpdate.run();
					break;
				case "0":	// 관리자
					break;
				case "e":	// 프로그램 종료
					Cw.wn("프로그램을 종료합니다.");
					break loop;
				}
			}
	}
	
	
}
