package com.skylaon.c.board.display;

import com.skylaon.util.Cw;

public class Display {
	private static String MAIN_MENU_BAR = "=============================================================================";
	private static String MAIN_MENU = "[1]글 리스트 [2]게시물 검색 [3]글 읽기 [4]글쓰기 [5]글삭제 [6]글수정 [0]관리자 [e]프로그램종료";
	 
	public static void showTitle() {
		Cw.wn("\r\n"
				+ "      :::::::::       ::::::::           :::        :::::::::       ::::::::: \r\n"
				+ "     :+:    :+:     :+:    :+:        :+: :+:      :+:    :+:      :+:    :+: \r\n"
				+ "    +:+    +:+     +:+    +:+       +:+   +:+     +:+    +:+      +:+    +:+  \r\n"
				+ "   +#++:++#+      +#+    +:+      +#++:++#++:    +#++:++#:       +#+    +:+   \r\n"
				+ "  +#+    +#+     +#+    +#+      +#+     +#+    +#+    +#+      +#+    +#+    \r\n"
				+ " #+#    #+#     #+#    #+#      #+#     #+#    #+#    #+#      #+#    #+#     \r\n"
				+ "#########       ########       ###     ###    ###    ###      #########       \r\n"
				+ ""
				);
	}
	
	public static void showMenu() {
		Cw.wn(MAIN_MENU_BAR);
		Cw.wn(MAIN_MENU);
		Cw.wn(MAIN_MENU_BAR);
	}
	
	public static void titleList() {
		Cw.wn("============================================================");
		Cw.wn("번호\t제목\t글쓴이\t조회수\t댓글수\t작성일\t[게시물 리스트]");
		Cw.wn("============================================================");
	}
}
