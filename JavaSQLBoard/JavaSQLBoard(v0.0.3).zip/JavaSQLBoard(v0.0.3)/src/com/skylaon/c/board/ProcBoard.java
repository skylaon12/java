package com.skylaon.c.board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.skylaon.c.board.display.Display;

public class ProcBoard {
	Connection con = null;
	Statement st = null;
	ResultSet result = null;
	Scanner sc = new Scanner(System.in);
	
	void run() {
		Display.showTitle();
		dbInit();
		
		loop:
			while(true) {
				dbPostCount();
				Display.showMenu();
				System.out.print("명령 입력: ");
				String cmd = sc.next();
				switch (cmd) {
				case "1":	// 글리스트
					try {
						result = st.executeQuery("select * from board;");
						System.out.println("번호\t제목\t글쓴이\t조회수\t작성일");
						while(result.next()) {// 결과를 하나씩 빼기. 더이
							int index = result.getInt("b_no");
							String title = result.getString("b_title");
							String writer = result.getString("b_id");
							int hit = result.getInt("b_hit");
							String date = result.getString("b_datetime");
							
							System.out.println(index + "\t" + title + "\t" + writer + "\t" + hit + "\t" + date);
						}
					} catch (SQLException e) {
						System.out.println("SQLException : " + e.getMessage());
						System.out.println("SQLState : " + e.getSQLState());
					}

					break;
				case "2":	// 글읽기
					System.out.println("읽을 글 번호를 입력해주세요 : ");
					String readNo = sc.next();
					try {
						result = st.executeQuery("select * from board where b_no = " + readNo);
						result.next();	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨
						String title = result.getString("b_title");
						String content = result.getString("b_text");
						System.out.println("글 제목 : " + title);
						System.out.println("글 내용 : " + content);
					} catch (SQLException e) {
						// TODO: handle exception
					}
					break;
				case "3":	// 글쓰기
					System.out.print("작성자 id : ");
					String writer = sc.nextLine();
					System.out.print("글 제목 : ");
					String title = sc.nextLine();
					System.out.print("내용 입력 : ");
					String contents = sc.next();
					
					
					dbExecuteUpdate("insert into board(b_title, b_id, b_datetime, b_text) values('"+title+"','" + writer + "',now(),'" + contents + "');");		
					System.out.println("등록이 완료되었습니다.");
					break;
				case "4":	// 글삭제
					System.out.println("삭제할 글 번호 : ");
					String no = sc.next();
					dbExecuteUpdate("delete from board where b_no = " + no + ";");
					break;
				case "5":	// 글수정
					System.out.println("수정할 글 번호를 입력해주세요 : ");
					String editNo = sc.next();
					System.out.println("제목 : ");
					String editTitle = sc.next();
					System.out.println("내용 : ");
					String editContent = sc.next();
					
					dbExecuteUpdate("update board set b_title = '" + editTitle + "',b_text = '" + editContent + "' where b_no = " + editNo + ";");
					
					
				case "0":	// 관리자
					break;
				case "e":	// 프로그램 종료
					System.out.println("프로그램을 종료합니다.");
					break loop;
				}
			}
	}
	
	private void dbInit() {
		try {
			// (1/n) 디비 접속 정보 넣어서 접속하기
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_board","root","root");
			// (2/n) Statement 객체 얻어오기.
			st = con.createStatement(); // Statement는 정적 SQL문을 실행하고 결과를 반환받기 위한 객체다. Statement 하나당 하나의 ResultSet 객체만을 열 수 있다.
			System.out.println("DB Connection OK");
		}catch (SQLException e) {
			System.out.println("SQLException " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
		
	}
	
	private void dbExecuteUpdate(String query) {
		try {
			// (3/n) Statement 객체의 executeUpdate 함수에 sql문 실어서 db에서 실행되게 하기
			int resultCount = st.executeUpdate(query);
			System.out.println("처리된 행 수 : " + resultCount);
		} catch (SQLException e) {
			System.out.println("SQLException : " + e.getMessage());
			System.out.println("SQLState : " + e.getSQLState());
		}
	}
	
	private void dbPostCount() {
		try {
			// (3/n) Statement 객체의 executeUpdate 함수에 sql문 실어서 db에서 실행되게 하기
			result = st.executeQuery("select count(*) from board;");
			result.next();
			String count = result.getString("count(*)");
			System.out.println("게시물 수 : " + count);
		} catch (SQLException e) {
			System.out.println("SQLException : " + e.getMessage());
			System.out.println("SQLState : " + e.getSQLState());
		}
	}
	
}
