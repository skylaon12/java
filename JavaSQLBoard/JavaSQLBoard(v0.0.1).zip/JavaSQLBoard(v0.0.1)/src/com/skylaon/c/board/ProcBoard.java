package com.skylaon.c.board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ProcBoard {
	Connection con = null;
	Statement st = null;
	ResultSet result = null;
	
	void run() {
		dbInit();
		//dbExecuteUpdate("insert into board(b_title, b_id, b_datetime, b_text) values('콘솔','skylaon',now(),'콘솔프로그램에서 작성한 글입니다.');");
		dbExecuteUpdate("update board set b_title='콘솔' where b_no = 4;");
		dbExecuteQuery("select * from board");
	}
	
	private void dbInit() {
		try {
			// (1/n) 디비 접속 정보 넣어서 접속하기
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_board","root","root");
			// (2/n) Statement 객체 얻어오기.
			st = con.createStatement(); // Statement는 정적 SQL문을 실행하고 결과를 반환받기 위한 객체다. Statement 하나당 하나의 ResultSet 객체만을 열 수 있다.
		}catch (SQLException e) {
			System.out.println("SQLException " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
		
	}
	
	private void dbExecuteQuery(String query) {
		try {
			result = st.executeQuery(query);
			System.out.println("번호\t제목\t글쓴이\t조회수\t작성일");
			while(result.next()) {// 결과를 하나씩 빼기. 더이
				int index = result.getInt("b_no");
				String title = result.getString("b_title");
				String writer = result.getString("b_id");
				int hit = result.getInt("b_hit");
				String date = result.getString("b_datetime");
				
				System.out.println(index + "\t" + title + "\t" + writer + "\t" + hit + "\t" + date);
			}
		} catch (SQLException e) {
			System.out.println("SQLException : " + e.getMessage());
			System.out.println("SQLState : " + e.getSQLState());
		}
	}
	
	private void dbExecuteUpdate(String query) {
		try {
			// (3/n) Statement 객체의 executeUpdate 함수에 sql문 실어서 db에서 실행되게 하기
			int resultCount = st.executeUpdate(query);
			System.out.println("처리된 행 수 : " + resultCount);
		} catch (SQLException e) {
			System.out.println("SQLException : " + e.getMessage());
			System.out.println("SQLState : " + e.getSQLState());
		}
	}
	
}
