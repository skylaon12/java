package com.skylaon.c.board;

public class Main {

	public static void main(String[] args) {
		ProcBoard procBoard = new ProcBoard();
		procBoard.run();
		
	}

}
