package com.skylaon.mysqltest;

import com.skylaon.util.Ci;
import com.skylaon.util.Db;

public class ProcUpdate {
	public static void run() {
		String editNo = Ci.r("수정할 글 번호를 입력해주세요");
		String editTitle = Ci.rl("제목");
		String editContent = Ci.rl("내용");
		String sql = "update board set b_title = '" + editTitle + "',b_text = '" + editContent + "' where b_no = " + editNo + ";";			
		Db.dbExecuteUpdate(sql);
	}
}
