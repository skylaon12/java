package com.skylaon.mysqltest;

import java.sql.SQLException;

import com.skylaon.util.Ci;
import com.skylaon.util.Cw;
import com.skylaon.util.Db;

public class ProcRead {
	public static void run() {
		String readNo = Ci.r("읽을 글 번호를 입력해주세요 : ");
		try {
			Db.dbExecuteUpdate("update board set b_hit = b_hit + 1 where b_no = " + readNo);
			Db.result = Db.st.executeQuery("select * from board where b_no = " + readNo);
			Db.result.next();	// 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨
			String title = Db.result.getString("b_title");
			String content = Db.result.getString("b_text");
			Cw.wn("글 제목 : " + title);
			Cw.wn("글 내용 : " + content);
		} catch (SQLException e) {
			Db.dbException(e);
		}
	}
}
