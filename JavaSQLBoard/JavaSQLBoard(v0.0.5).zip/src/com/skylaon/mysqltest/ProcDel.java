package com.skylaon.mysqltest;

import com.skylaon.util.Ci;
import com.skylaon.util.Db;

public class ProcDel {
	public static void run() {
		String no = Ci.r("삭제할 글 번호 : ");
		Db.dbExecuteUpdate("delete from board where b_no = " + no + ";");
		// `삭제 이후에 b_no를 재정렬
		Db.dbExecuteUpdate("alter table board auto_increment=1;");
		Db.dbExecuteUpdate("set @count = 0;");
		Db.dbExecuteUpdate("update board set b_no = @count :=@count+1");
	}
}
