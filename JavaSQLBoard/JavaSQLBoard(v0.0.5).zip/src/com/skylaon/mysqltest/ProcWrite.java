package com.skylaon.mysqltest;

import java.sql.SQLException;

import com.skylaon.util.Ci;
import com.skylaon.util.Cw;
import com.skylaon.util.Db;

public class ProcWrite {
	public static void run() {
		String writer = Ci.r("작성자 id");
		String title = Ci.r("글 제목");
		String contents = Ci.r("내용 입력");
		int in_no = 0;	// b_no 조정
		try {// board 테이블의 마지막 행의 번호를 가져와 임시변수 in_no에 저장
			Db.result = Db.st.executeQuery("select b_no from board order by b_no desc limit 1");
			Db.result.next();
			in_no = Db.result.getInt("b_no");						
		} catch (SQLException e) {
			Db.dbException(e);
		}
		// 글 등록하기 전에 b_no를 마지막 행의 번호 다음으로 지정
		Db.dbExecuteUpdate("alter table board auto_increment = " + in_no + ";");
		Db.dbExecuteUpdate("insert into board(b_title, b_id, b_datetime, b_text) values('"+title+"','" + writer + "',now(),'" + contents + "');");		
		Cw.wn("등록이 완료되었습니다.");
	}
}
